create view result as
  WITH RECURSIVE kv(timeclose, iddivision, count, namedivision) AS (
    SELECT (i.timeclose)::date AS timeclose,
           i.iddivision,
           count(*)            AS count,
           d.namedivision
    FROM incident i,
         division d
    WHERE ((i.iddivision = d.iddivision) AND
           ((date_part('week'::text, CURRENT_DATE) - (1)::double precision) = date_part('week'::text, i.timeclose)))
    GROUP BY i.iddivision, ((i.timeclose)::date), d.namedivision
  ),
                 skv(timeclose, iddivision, count) AS (
                   SELECT (i.timeclose)::date AS timeclose,
                          i.iddivision,
                          count(*)            AS count,
                          d.namedivision
                   FROM incident i,
                        division d
                   WHERE ((i.iddivision = d.iddivision) AND
                          ((date_part('week'::text, CURRENT_DATE) - (1)::double precision) =
                           date_part('week'::text, i.timeclose)) AND (i.controlterm < i.timeclose))
                   GROUP BY i.iddivision, ((i.timeclose)::date), d.namedivision
                 )
  SELECT kv.timeclose,
         kv.iddivision,
         COALESCE(kv.count, (0)::bigint)  AS kvcount,
         COALESCE(skv.count, (0)::bigint) AS skvcount,
         kv.namedivision
  FROM (kv
         LEFT JOIN skv USING (iddivision, timeclose))
  ORDER BY kv.iddivision;

alter table result
  owner to ura;

