create view users as
SELECT pg_user.usename,
       pg_user.passwd
FROM pg_user;

alter table users
  owner to ura;

