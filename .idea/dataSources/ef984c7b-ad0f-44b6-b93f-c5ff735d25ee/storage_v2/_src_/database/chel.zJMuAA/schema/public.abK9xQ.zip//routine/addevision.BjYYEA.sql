create function addevision(integer, text) returns integer
  language plpgsql
as
$$
DECLARE
i integer;

BEGIN
 SELECT  iddevision
 FROM devision
 INTO  i
 where namedevision = $2;

 IF NOT FOUND THEN
  select idtit from city into i where idcity = $1; 
  INSERT INTO devision AS w (idtit, namedevision) VALUES (i , $2) returning iddevision;
        ELSE
  RETURN i;
 END IF; 
 END
$$;

alter function addevision(integer, text) owner to ura;

